function greet() {
    console.log("Hey USER WELCOME TO THE CLOUD!");
}

function greetByName(name) {
    return { name: name };
}

export default { greet, greetByName };
